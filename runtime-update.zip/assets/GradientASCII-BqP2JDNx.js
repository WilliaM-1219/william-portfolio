import{r as P,j as Ie}from"./index-1lJZYtXS.js";const Ge=8,se=4,ue=24,Pe=1.2,Oe=.7,Xe=.015,st=2.4,Q=60,q=100,ut=16,lt=.78,ke=["#1e3fd8","#f6f8ff","#a5d8ff","#38bdf8"],Ne=" =+xX0S8#@",qe='"Geist Mono", ui-monospace, SFMono-Regular, Menlo, Consolas, monospace',ft={horizon:0,pinch:1,rise:2,eclipse:3},mt={none:0,wave:1,burst:2},dt=`#version 300 es
out vec2 vUv;
void main() {
  vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
  vUv = p;
  gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
}`,Ve=`
float hash12(vec2 p) {
  vec3 q = fract(vec3(p.xyx) * 0.1031);
  q += dot(q, q.yzx + 33.33);
  return fract((q.x + q.y) * q.z);
}
`,ht=`#version 300 es
precision highp float;
precision highp int;
uniform float uAspect;
uniform float uTime;
uniform int uShape;
uniform vec3 uRamp[8];
uniform int uCount;
uniform float uScale;
uniform float uSoftness;
uniform float uFlow;
uniform vec2 uSeed;
uniform vec4 uTrail[24];
uniform float uRadius;
uniform vec4 uClicks[4];
uniform int uClickEffect;
uniform float uIntro;
uniform float uFrame;
in vec2 vUv;
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outAux;
${Ve}
vec2 hash22(vec2 p) {
  vec3 q = fract(vec3(p.xyx) * vec3(0.1031, 0.103, 0.0973));
  q += dot(q, q.yzx + 33.33);
  return fract((q.xx + q.yz) * q.zy) * 2.0 - 1.0;
}

float noise(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  vec2 u = f * f * f * (f * (f * 6.0 - 15.0) + 10.0);
  float a = dot(hash22(i), f);
  float b = dot(hash22(i + vec2(1.0, 0.0)), f - vec2(1.0, 0.0));
  float c = dot(hash22(i + vec2(0.0, 1.0)), f - vec2(0.0, 1.0));
  float d = dot(hash22(i + vec2(1.0, 1.0)), f - vec2(1.0, 1.0));
  return 0.5 + 0.5 * mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

vec3 labToRgb(vec3 lab) {
  float l = lab.x + 0.3963377774 * lab.y + 0.2158037573 * lab.z;
  float m = lab.x - 0.1055613458 * lab.y - 0.0638541728 * lab.z;
  float s = lab.x - 0.0894841775 * lab.y - 1.2914855480 * lab.z;
  l = l * l * l;
  m = m * m * m;
  s = s * s * s;
  return vec3(
    4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s,
    -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s,
    -0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s
  );
}

vec3 encode(vec3 c) {
  c = clamp(c, 0.0, 1.0);
  return mix(c * 12.92, 1.055 * pow(c, vec3(1.0 / 2.4)) - 0.055, step(0.0031308, c));
}

vec3 horizon(vec2 p, float time, out float order) {
  float span = 0.5 * max(uAspect, 1.0);
  float x = p.x / span;
  float arch = -0.17 - 0.2 * x * x + 0.02 * sin(time * 0.6);
  float soft = mix(0.05, 0.22, uSoftness);
  float edge = p.y - arch;
  float rim = 0.38 * smoothstep(-soft, 0.42, edge);
  vec2 sun = vec2(0.08 * sin(time * 0.31) * span, 0.58);
  float spread = length((p - sun) / vec2(0.95 * span, 0.75));
  float sky = mix(0.55, 1.0, smoothstep(0.2, 0.95, spread));
  order = clamp(edge * 1.3, 0.0, 1.0);
  return vec3(rim, sky, smoothstep(0.18, 0.62, edge));
}

vec3 pinch(vec2 p, float time, out float order) {
  float span = 0.5 * max(uAspect, 0.75);
  float x = p.x / span;
  float sway = 0.02 * sin(x * 1.7 + time * 0.55);
  float breathe = 1.0 + 0.06 * sin(time * 0.8);
  float width = (0.13 + 0.22 * x * x) * breathe * mix(0.85, 1.2, uSoftness);
  float y = abs(p.y - sway) / width;
  float t = exp(-pow(y, 2.2)) * (0.42 + 0.58 * exp(-x * x * 1.8));
  order = clamp(abs(p.y - sway) * 2.4 + abs(x) * 0.3, 0.0, 1.0);
  return vec3(t, t, 0.0);
}

vec3 rise(vec2 p, float time, out float order) {
  float wide = max(uAspect, 0.9);
  vec2 center = vec2(0.05 * sin(time * 0.45) * wide, -0.7);
  vec2 radius = vec2(0.82 * wide, 0.64 * (1.0 + 0.04 * sin(time * 0.8)));
  float d = length((p - center) / radius);
  float soft = mix(0.6, 1.15, uSoftness);
  float t = clamp(pow(clamp(1.0 - d, 0.0, 1.0), soft) * 1.35, 0.0, 1.0);
  order = clamp((d - 0.2) * 1.3, 0.0, 1.0);
  return vec3(t, t, 0.0);
}

vec3 eclipse(vec2 p, float time, out float order) {
  float fit = min(1.0, uAspect * 1.25);
  float r = 0.23 * fit * (1.0 + 0.015 * sin(time * 0.9));
  float angle = atan(p.y, p.x);
  float rays = noise(vec2(cos(angle), sin(angle)) * 2.2 + time * 0.08) * 0.8 + 0.6;
  float d = length(p) - r;
  float reach = mix(0.07, 0.15, uSoftness) * rays * fit;
  float t = smoothstep(-0.006, 0.006 + 0.02 * uSoftness, d) * exp(-max(d, 0.0) / reach);
  order = clamp(d * 2.0, 0.0, 1.0);
  return vec3(t, t, 0.0);
}

vec4 tone(float t) {
  float x = smoothstep(0.3, 1.0, t) * float(uCount - 1);
  int index = int(floor(x));
  return vec4(mix(uRamp[index], uRamp[min(index + 1, uCount - 1)], fract(x)), smoothstep(0.0, 0.38, t));
}

void main() {
  vec2 p = (vUv - 0.5) * vec2(uAspect, 1.0);
  float time = uTime;
  vec2 q = p / uScale;
  vec2 warp = vec2(
    noise(q * 1.6 + uSeed + vec2(0.0, time * 0.3)),
    noise(q * 1.6 + uSeed.yx + vec2(4.3, -time * 0.24))
  ) - 0.5;
  q += warp * uFlow * (uShape == 3 ? 0.04 : 0.18);
  float order = 0.0;
  vec3 shape;
  if (uShape == 0) shape = horizon(q, time, order);
  else if (uShape == 1) shape = pinch(q, time, order);
  else if (uShape == 2) shape = rise(q, time, order);
  else shape = eclipse(q, time, order);

  float reveal = clamp((uIntro * 1.45 - order) / 0.45, 0.0, 1.0);
  reveal = reveal * reveal * (3.0 - 2.0 * reveal);

  float scramble = 0.0;
  for (int i = 0; i < 24; i++) {
    vec4 point = uTrail[i];
    if (point.z <= 0.0) continue;
    vec2 d = p - point.xy;
    scramble = max(scramble, point.z * exp(-dot(d, d) / (uRadius * uRadius)));
  }
  for (int i = 0; i < 4; i++) {
    vec4 c = uClicks[i];
    if (c.w <= 0.0) continue;
    float d = length(p - c.xy);
    if (uClickEffect == 1) {
      scramble = max(scramble, exp(-pow((d - c.z * 0.75) / 0.06, 2.0)) * c.w);
    } else if (uClickEffect == 2) {
      float size = 0.08 + 0.22 * (1.0 - exp(-c.z * 5.0));
      scramble = max(scramble, (1.0 - smoothstep(size * 0.6, size, d)) * c.w);
    }
  }
  vec2 t = clamp(shape.xy * mix(0.7, 1.0, reveal), 0.0, 1.0);
  vec4 mixed = mix(tone(t.x), tone(t.y), shape.z);
  vec3 color = encode(labToRgb(mixed.rgb));
  float alpha = mixed.a * reveal;
  float dither = (hash12(gl_FragCoord.xy + uFrame * 13.7) - 0.5) / 255.0;
  outColor = clamp(vec4(color * alpha + dither, alpha + dither), 0.0, 1.0);
  outAux = vec4(reveal, scramble, 0.0, 1.0);
}`,$e=`
uniform sampler2D uField;
uniform sampler2D uAux;
uniform sampler2D uAtlas;
uniform vec2 uResolution;
uniform vec2 uCell;
uniform vec2 uOffset;
uniform vec2 uAtlasGrid;
uniform float uCount;
uniform float uDensity;
uniform float uOpacity;
uniform float uFlicker;
uniform float uDepth;
uniform float uGlyphTime;
uniform float uSeedValue;
uniform float uLight;
${Ve}
float sampleGlyph(float index, vec2 local, vec2 coord, float soft) {
  float column = mod(index, uAtlasGrid.x);
  float row = floor(index / uAtlasGrid.x);
  vec2 atlasUv = vec2((column + local.x) / uAtlasGrid.x, (row + 1.0 - local.y) / uAtlasGrid.y);
  vec2 continuous = coord / uAtlasGrid;
  float scale = exp2(soft);
  return textureGrad(uAtlas, atlasUv, dFdx(continuous) * scale, dFdy(continuous) * scale).a;
}

vec4 glyphAt(vec2 px) {
  vec2 coord = (px - uOffset) / uCell;
  vec2 cell = floor(coord);
  vec2 local = coord - cell;
  vec2 uv = clamp(((cell + 0.5) * uCell + uOffset) / uResolution, vec2(0.0), vec2(1.0));
  vec4 field = texture(uField, uv);
  vec4 aux = texture(uAux, uv);
  vec3 visible = uLight > 0.5 ? field.rgb + (1.0 - field.a) : field.rgb;
  float luma = dot(visible, vec3(0.2126, 0.7152, 0.0722));
  float value = uLight > 0.5 ? clamp((1.0 - luma) * 1.5, 0.0, 1.0) : luma;
  float pick = hash12(cell + uSeedValue * 7.31);
  float level = hash12(cell * 1.73 + 4.1 + uSeedValue);
  float tick = floor(uGlyphTime * 9.0 + level * 9.0);
  float wobble = (hash12(cell * 2.31 + tick * 17.7) - 0.5) * uFlicker * 0.4 + (level - 0.5) * 0.1;
  float tone = clamp(pow(value, 0.75) + wobble, 0.0, 1.0);
  float index = floor(tone * (uCount - 1.0) + 0.5);
  float decode = max(aux.g, 1.0 - aux.r);
  if (decode > 0.02) {
    float frame = floor(uGlyphTime * 20.0);
    if (hash12(cell * 3.7 + frame * 5.3) < decode * 1.25) index = 1.0 + floor(hash12(cell + frame * 1.37) * (uCount - 1.0));
  }
  float present = step(pick, uDensity * mix(1.0, 0.3 + tone * 1.1, 0.55));
  float cutoff = smoothstep(0.03, 0.1, value);
  float focus = step(hash12(cell * 0.71 + 9.2 + uSeedValue), uDepth);
  float coverage = sampleGlyph(index, local, coord, focus * 1.2);
  float alpha = uOpacity * present * cutoff * coverage * mix(1.0, 0.35 + 0.65 * level, 0.55) * (1.0 - focus * 0.5);
  if (uLight < 0.5) {
    vec3 light = field.rgb * 0.55 + vec3(0.03) * field.a;
    return vec4(light * alpha, 0.6 * field.a * alpha);
  }
  vec3 ink = visible * 0.8;
  return vec4(ink * alpha, alpha);
}
`,pt=`#version 300 es
precision highp float;
uniform float uDownscale;
in vec2 vUv;
out vec4 outColor;
${$e}
void main() {
  outColor = glyphAt(gl_FragCoord.xy * uDownscale);
}`,vt=`#version 300 es
precision highp float;
uniform sampler2D uSource;
uniform vec2 uStep;
in vec2 vUv;
out vec4 outColor;
void main() {
  vec4 sum = texture(uSource, vUv) * 0.2270270270;
  sum += texture(uSource, vUv + uStep * 1.3846153846) * 0.3162162162;
  sum += texture(uSource, vUv - uStep * 1.3846153846) * 0.3162162162;
  sum += texture(uSource, vUv + uStep * 3.2307692308) * 0.0702702703;
  sum += texture(uSource, vUv - uStep * 3.2307692308) * 0.0702702703;
  outColor = sum;
}`,xt=`#version 300 es
precision highp float;
uniform sampler2D uHalo;
uniform float uGlow;
uniform float uGradient;
uniform float uGrain;
uniform float uFrame;
in vec2 vUv;
out vec4 outColor;
${$e}
void main() {
  vec4 base = texture(uField, vUv) * uGradient;
  vec4 glyph = glyphAt(gl_FragCoord.xy);
  vec4 halo = texture(uHalo, vUv) * uGlow;
  vec4 color;
  if (uLight < 0.5) {
    color = base + glyph + halo;
  } else {
    color = glyph + base * (1.0 - glyph.a);
    color += halo * 0.6 * (1.0 - color.a);
  }
  float grain = (hash12(gl_FragCoord.xy + uFrame * vec2(17.0, 59.0)) + hash12(gl_FragCoord.xy * 1.31 + uFrame * 7.0) - 1.0) * uGrain;
  float body = clamp(color.a, 0.0, 1.0);
  color.rgb += grain * (0.25 + body) * 0.5;
  color.a = clamp(color.a, 0.0, 1.0);
  color.rgb = clamp(color.rgb, 0.0, color.a);
  outColor = color;
}`,p=(t,s,u)=>Math.min(u,Math.max(s,t)),le=t=>t<=.04045?t/12.92:((t+.055)/1.055)**2.4,Et=([t,s,u])=>{const c=le(t),f=le(s),m=le(u),g=Math.cbrt(.4122214708*c+.5363325363*f+.0514459929*m),T=Math.cbrt(.2119034982*c+.6806995451*f+.1073969566*m),v=Math.cbrt(.0883024619*c+.2817188376*f+.6299787005*m);return[.2104542553*g+.793617785*T-.0040720468*v,1.9779984951*g-2.428592205*T+.4505937099*v,.0259040371*g+.7827717662*T-.808675766*v]},ze=(t,s,u)=>{const c=t.createShader(s);return c?(t.shaderSource(c,u),t.compileShader(c),c):null},J=(t,s)=>{const u=ze(t,t.VERTEX_SHADER,dt),c=ze(t,t.FRAGMENT_SHADER,s),f=t.createProgram();return!u||!c||!f?null:(t.attachShader(f,u),t.attachShader(f,c),t.linkProgram(f),t.deleteShader(u),t.deleteShader(c),{program:f,uniforms:{}})},Be=(t,s)=>{if(!t.getProgramParameter(s.program,t.LINK_STATUS))return!1;const u=t.getProgramParameter(s.program,t.ACTIVE_UNIFORMS);for(let c=0;c<u;c++){const f=t.getActiveUniform(s.program,c);if(!f)continue;const m=f.name.replace(/\[0\]$/,"");s.uniforms[m]=t.getUniformLocation(s.program,m)}return!0},fe=(t,s)=>({textures:Array.from({length:s},()=>{const c=t.createTexture();return t.bindTexture(t.TEXTURE_2D,c),t.texParameteri(t.TEXTURE_2D,t.TEXTURE_MIN_FILTER,t.LINEAR),t.texParameteri(t.TEXTURE_2D,t.TEXTURE_MAG_FILTER,t.LINEAR),t.texParameteri(t.TEXTURE_2D,t.TEXTURE_WRAP_S,t.CLAMP_TO_EDGE),t.texParameteri(t.TEXTURE_2D,t.TEXTURE_WRAP_T,t.CLAMP_TO_EDGE),c}),framebuffer:t.createFramebuffer(),width:0,height:0}),me=(t,s,u,c)=>{s.width===u&&s.height===c||(s.width=u,s.height=c,t.bindFramebuffer(t.FRAMEBUFFER,s.framebuffer),s.textures.forEach((f,m)=>{t.bindTexture(t.TEXTURE_2D,f),t.texImage2D(t.TEXTURE_2D,0,t.RGBA8,u,c,0,t.RGBA,t.UNSIGNED_BYTE,null),t.framebufferTexture2D(t.FRAMEBUFFER,t.COLOR_ATTACHMENT0+m,t.TEXTURE_2D,f,0)}),t.bindFramebuffer(t.FRAMEBUFFER,null))},He=(t,s,u)=>{const c=[...new Set([...s].filter(M=>M!==`
`&&M!=="\r"))];c.length||c.push(" ");const f=`300 ${Math.round(q*lt)}px ${u}`,m=Math.min(ut,c.length),g=Math.ceil(c.length/m),T=document.createElement("canvas");T.width=Q*m,T.height=q*g;const v=T.getContext("2d");v&&(v.font=f,v.textAlign="center",v.textBaseline="middle",v.fillStyle="#fff",c.forEach((M,B)=>{const Z=B%m,ee=Math.floor(B/m);v.fillText(M,Z*Q+Q/2,ee*q+q/2+3)}));const z=t.createTexture();return t.bindTexture(t.TEXTURE_2D,z),t.pixelStorei(t.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),t.texImage2D(t.TEXTURE_2D,0,t.RGBA8,t.RGBA,t.UNSIGNED_BYTE,T),t.generateMipmap(t.TEXTURE_2D),t.texParameteri(t.TEXTURE_2D,t.TEXTURE_MIN_FILTER,t.LINEAR_MIPMAP_LINEAR),t.texParameteri(t.TEXTURE_2D,t.TEXTURE_MAG_FILTER,t.LINEAR),t.texParameteri(t.TEXTURE_2D,t.TEXTURE_WRAP_S,t.CLAMP_TO_EDGE),t.texParameteri(t.TEXTURE_2D,t.TEXTURE_WRAP_T,t.CLAMP_TO_EDGE),{texture:z,count:c.length,grid:[m,g]}},yt=({colors:t=ke,shape:s="horizon",characters:u=Ne,cellSize:c=18,density:f=.8,glyphOpacity:m=.85,glow:g=.2,depthOfField:T=0,flicker:v=.2,softness:z=.5,scale:M=1,flow:B=.5,speed:Z=1,gradientOpacity:ee=.9,grain:We=.08,variation:Ke=0,mouseInteraction:je=!0,scrambleRadius:Ye=.1,clickEffect:Je="wave",intro:Qe=!0,lightMode:Ze=!1,fontFamily:et=qe,dpr:tt,className:de="",style:ot,...rt})=>{const he=P.useRef(null),pe=P.useRef(null),te=P.useRef(null),H=(Array.isArray(t)&&t.length?t:ke).slice(0,Ge),ve={colors:H.length>1?H:[H[0],H[0]],shape:ft[s]??0,characters:u||Ne,cellSize:p(c,6,64),density:p(f,0,1),glyphOpacity:p(m,0,1),glow:p(g,0,2),depthOfField:p(T,0,1),flicker:p(v,0,1),softness:p(z,0,1),scale:p(M,.4,2.5),flow:p(B,0,2),speed:Math.max(0,Z),gradientOpacity:p(ee,0,1),grain:p(We,0,.4),variation:Math.max(0,Ke),mouseInteraction:je,scrambleRadius:p(Ye,.02,.4),clickEffect:mt[Je]??1,intro:Qe,lightMode:Ze,fontFamily:et||qe,dpr:tt},y=P.useRef(ve);return y.current=ve,P.useEffect(()=>{const C=he.current,l=pe.current,e=l?.getContext("webgl2",{alpha:!0,premultipliedAlpha:!0,antialias:!1,depth:!1,stencil:!1});if(!C||!l||!e)return;const V=e.getExtension("KHR_parallel_shader_compile"),$=J(e,ht),O=J(e,pt),L=J(e,vt),X=J(e,xt);if(!$||!O||!L||!X)return;const U=[$,O,L,X];if(!V&&!U.every(r=>Be(e,r))){U.forEach(r=>e.deleteProgram(r.program));return}const xe=e.createVertexArray(),w=fe(e,2),E=fe(e,1),W=fe(e,1),D=document.createElement("canvas").getContext("2d",{willReadFrequently:!0}),Ee=new Map,at=r=>{const a=String(r),o=Ee.get(a);if(o)return o;let n=[0,0,0];if(D){D.clearRect(0,0,1,1),D.fillStyle="#000000",D.fillStyle=a,D.fillRect(0,0,1,1);const[i,b,_]=D.getImageData(0,0,1,1).data;n=[i/255,b/255,_/255]}return Ee.set(a,n),n},S=window.matchMedia?.("(prefers-reduced-motion: reduce)").matches??!1,R={width:1,height:1,ratio:1},Te=new Float32Array(Ge*3),oe=new Float32Array(se*4),A=[],re=new Float32Array(ue*4),x=[],h={x:0,y:0,inside:!1};let d=null,ae="",ye="",Re=0,Ae=0,k=y.current.intro&&!S?0:1,K=0,ie=0,I=0,G=0,j=!0,N=!1,Y=!V;const be=()=>!V||U.every(r=>e.getProgramParameter(r.program,V.COMPLETION_STATUS_KHR)),ge=()=>{if(!e.isContextLost()){if(!Y&&!be()){requestAnimationFrame(ge);return}U.forEach(r=>e.deleteProgram(r.program))}},it=()=>{const r=y.current,a=`${r.fontFamily}|${r.characters}`;a===ae&&d||(ae=a,d&&e.deleteTexture(d.texture),d=He(e,r.characters,r.fontFamily),document.fonts?.load?.(`300 64px ${r.fontFamily}`,r.characters).then(()=>{N||ae!==a||(d&&e.deleteTexture(d.texture),d=He(e,r.characters,r.fontFamily),ne())},()=>{}))},nt=()=>{const r=y.current,a=r.colors.join(",");a!==ye&&(ye=a,r.colors.forEach((o,n)=>Te.set(Et(at(o)),n*3)))},we=(r,a,o)=>{if(!d)return;const n=y.current,i=r.uniforms,b=n.cellSize*R.ratio,_=b*(Q/q);e.activeTexture(e.TEXTURE0),e.bindTexture(e.TEXTURE_2D,w.textures[0]),e.uniform1i(i.uField,0),e.activeTexture(e.TEXTURE1),e.bindTexture(e.TEXTURE_2D,w.textures[1]),e.uniform1i(i.uAux,1),e.activeTexture(e.TEXTURE2),e.bindTexture(e.TEXTURE_2D,d.texture),e.uniform1i(i.uAtlas,2),e.uniform2f(i.uResolution,a,o),e.uniform2f(i.uCell,_,b),e.uniform2f(i.uOffset,(a-Math.ceil(a/_)*_)/2,(o-Math.ceil(o/b)*b)/2),e.uniform2f(i.uAtlasGrid,d.grid[0],d.grid[1]),e.uniform1f(i.uCount,d.count),e.uniform1f(i.uDensity,n.density),e.uniform1f(i.uOpacity,n.glyphOpacity),e.uniform1f(i.uFlicker,S?0:n.flicker),e.uniform1f(i.uDepth,n.depthOfField),e.uniform1f(i.uGlyphTime,Ae),e.uniform1f(i.uSeedValue,n.variation),e.uniform1f(i.uLight,n.lightMode?1:0)},ne=()=>{if(!Y)return;const r=y.current,a=R.width/R.height;it(),nt(),e.bindVertexArray(xe),e.disable(e.BLEND),e.bindFramebuffer(e.FRAMEBUFFER,w.framebuffer),e.drawBuffers([e.COLOR_ATTACHMENT0,e.COLOR_ATTACHMENT1]),e.viewport(0,0,w.width,w.height),e.useProgram($.program);const o=$.uniforms;e.uniform1f(o.uAspect,a),e.uniform1f(o.uTime,Re),e.uniform1i(o.uShape,r.shape),e.uniform3fv(o.uRamp,Te),e.uniform1i(o.uCount,r.colors.length),e.uniform1f(o.uScale,r.scale),e.uniform1f(o.uSoftness,r.softness),e.uniform1f(o.uFlow,r.flow),e.uniform2f(o.uSeed,r.variation*3.17,r.variation*1.91),e.uniform4fv(o.uTrail,re),e.uniform1f(o.uRadius,r.scrambleRadius),e.uniform4fv(o.uClicks,oe),e.uniform1i(o.uClickEffect,r.clickEffect),e.uniform1f(o.uIntro,k),e.uniform1f(o.uFrame,K),e.drawArrays(e.TRIANGLES,0,3);const n=r.glow>.001;n&&(e.bindFramebuffer(e.FRAMEBUFFER,E.framebuffer),e.drawBuffers([e.COLOR_ATTACHMENT0]),e.viewport(0,0,E.width,E.height),e.useProgram(O.program),we(O,l.width,l.height),e.uniform1f(O.uniforms.uDownscale,l.width/E.width),e.drawArrays(e.TRIANGLES,0,3),e.useProgram(L.program),e.activeTexture(e.TEXTURE0),e.uniform1i(L.uniforms.uSource,0),e.bindFramebuffer(e.FRAMEBUFFER,W.framebuffer),e.bindTexture(e.TEXTURE_2D,E.textures[0]),e.uniform2f(L.uniforms.uStep,1/E.width,0),e.drawArrays(e.TRIANGLES,0,3),e.bindFramebuffer(e.FRAMEBUFFER,E.framebuffer),e.bindTexture(e.TEXTURE_2D,W.textures[0]),e.uniform2f(L.uniforms.uStep,0,1/E.height),e.drawArrays(e.TRIANGLES,0,3)),e.bindFramebuffer(e.FRAMEBUFFER,null),e.viewport(0,0,l.width,l.height),e.useProgram(X.program),we(X,l.width,l.height);const i=X.uniforms;e.activeTexture(e.TEXTURE3),e.bindTexture(e.TEXTURE_2D,E.textures[0]),e.uniform1i(i.uHalo,3),e.uniform1f(i.uGlow,n?r.glow:0),e.uniform1f(i.uGradient,r.gradientOpacity),e.uniform1f(i.uGrain,r.grain),e.uniform1f(i.uFrame,K),e.drawArrays(e.TRIANGLES,0,3)},_e=()=>{const r=y.current;R.width=Math.max(1,C.clientWidth),R.height=Math.max(1,C.clientHeight),R.ratio=Math.min(r.dpr||window.devicePixelRatio||1,2);const a=Math.max(1,Math.round(R.width*R.ratio)),o=Math.max(1,Math.round(R.height*R.ratio));if(l.width===a&&l.height===o&&w.width){F();return}l.width!==a&&(l.width=a),l.height!==o&&(l.height=o),me(e,w,Math.max(1,Math.round(l.width/2)),Math.max(1,Math.round(l.height/2)));const n=Math.max(1,Math.round(l.width/4)),i=Math.max(1,Math.round(l.height/4));me(e,E,n,i),me(e,W,n,i),ne(),F()},ct=r=>{for(x.forEach(a=>{a.age+=r});x.length&&x[x.length-1].age>Oe;)x.pop();for(let a=0;a<ue;a++){const o=x[a];if(!o){re[a*4+2]=0;continue}const n=1-o.age/Oe;re.set([o.x,o.y,n*n,0],a*4)}for(A.forEach(a=>{a.age+=r});A.length&&A[A.length-1].age>Pe;)A.pop();for(let a=0;a<se;a++){const o=A[a];if(!o){oe[a*4+3]=0;continue}const n=o.age/Pe,i=Math.min(1,o.age/.08)*(1-n)*(1-n);oe.set([o.x,o.y,o.age,i],a*4)}},ce=r=>{if(I=0,N||!j||document.hidden)return;if(!Y){if(!e.isContextLost()&&!be()){I=requestAnimationFrame(ce);return}if(!U.every(i=>Be(e,i))){De();return}Y=!0}const a=y.current,o=G?p((r-G)/1e3,.001,.05):1/60;G=r,S||(Re+=o*a.speed*.5,Ae+=o*Math.max(a.speed,.15)),k<1&&(k=Math.min(1,k+o/st)),ie+=o,!S&&ie>1/24&&(ie=0,K=(K+1)%97),ct(o),ne(),!S||k<1||A.length>0||x.length>0?I=requestAnimationFrame(ce):G=0};function F(){!I&&!N&&j&&!document.hidden&&(I=requestAnimationFrame(ce))}const Se=r=>{const a=C.getBoundingClientRect(),o=(r.clientX-a.left)/Math.max(1,a.width),n=1-(r.clientY-a.top)/Math.max(1,a.height),i=a.width/Math.max(1,a.height);h.inside=o>=0&&o<=1&&n>=0&&n<=1,h.x=(o-.5)*i,h.y=n-.5},Fe=r=>{Se(r);const a=y.current;if(!h.inside||!a.mouseInteraction||S)return;const o=x[0],n=o?Math.hypot(h.x-o.x,h.y-o.y):1/0;if(!(n<Xe)){if(o&&o.age<.1){const i=Math.min(6,Math.floor(n/(Xe*2)));for(let b=1;b<=i;b++){const _=b/(i+1);x.unshift({x:o.x+(h.x-o.x)*_,y:o.y+(h.y-o.y)*_,age:0})}}x.unshift({x:h.x,y:h.y,age:0}),x.length=Math.min(x.length,ue),F()}},Me=r=>{Se(r);const a=y.current;!h.inside||!a.clickEffect||S||(A.unshift({x:h.x,y:h.y,age:0}),A.length>se&&A.pop(),F())},Ce=()=>{G=0,F()},Le=new ResizeObserver(_e);Le.observe(C);const Ue=new IntersectionObserver(r=>{j=r.some(a=>a.isIntersecting),j&&(G=0,F())});Ue.observe(C),window.addEventListener("pointermove",Fe,{passive:!0}),window.addEventListener("pointerdown",Me,{passive:!0}),document.addEventListener("visibilitychange",Ce),_e(),te.current=F;const De=()=>{N||(N=!0,cancelAnimationFrame(I),te.current=null,Le.disconnect(),Ue.disconnect(),window.removeEventListener("pointermove",Fe),window.removeEventListener("pointerdown",Me),document.removeEventListener("visibilitychange",Ce),[w,E,W].forEach(r=>{r.textures.forEach(a=>e.deleteTexture(a)),e.deleteFramebuffer(r.framebuffer)}),d&&e.deleteTexture(d.texture),e.deleteVertexArray(xe),l.isConnected?ge():(U.forEach(r=>e.deleteProgram(r.program)),e.getExtension("WEBGL_lose_context")?.loseContext()))};return De},[]),P.useEffect(()=>{te.current?.()}),Ie.jsx("div",{ref:he,className:`gradient-ascii-container${de?` ${de}`:""}`,style:ot,...rt,children:Ie.jsx("canvas",{ref:pe,className:"gradient-ascii-canvas","aria-hidden":"true"})})};export{yt as default};
