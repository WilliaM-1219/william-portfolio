import{r as T,j as W}from"./index-1lJZYtXS.js";const ce=" .'`^\",:;Il!i~+_-?][}{1)(|/tfjrxnuvczXYUJCLQ0OZmwqpdbkhao*#MW&8%B@$",we="'IBM Plex Mono', ui-monospace, SFMono-Regular, Menlo, Consolas, monospace",F=40,A=64,C=256,N=4,Le=`#version 300 es
in vec2 position;
void main() {
  gl_Position = vec4(position, 0.0, 1.0);
}`,Ie=`#version 300 es
precision highp float;
#define RIPPLES ${N}
uniform sampler2D uText;
uniform sampler2D uGlyphs;
uniform vec2 uSize;
uniform vec2 uCell;
uniform float uGlyphCount;
uniform float uTextAspect;
uniform float uPlaneHeight;
uniform vec2 uTilt;
uniform float uTime;
uniform float uWaves;
uniform float uWaveSpeed;
uniform float uChroma;
uniform float uBlocks;
uniform vec3 uColors[3];
uniform float uHue;
uniform vec2 uPointer;
uniform float uHover;
uniform float uScramble;
uniform vec4 uRipples[RIPPLES];
uniform float uIntro;
uniform float uLight;
uniform float uReady;
out vec4 fragColor;

float hash(vec2 p) {
  p = fract(p * vec2(123.34, 456.21));
  p += dot(p, p + 45.32);
  return fract(p.x * p.y);
}

vec3 hueRotate(vec3 color, float angle) {
  const vec3 axis = vec3(0.57735);
  float c = cos(angle);
  return color * c + cross(axis, color) * sin(angle) + axis * dot(axis, color) * (1.0 - c);
}

vec4 scene(vec2 pixel) {
  vec2 ndc = vec2(pixel.x / uSize.x * 2.0 - 1.0, 1.0 - pixel.y / uSize.y * 2.0);
  float tanHalf = 0.41421356;
  vec3 dir = normalize(vec3(ndc.x * tanHalf * uSize.x / uSize.y, ndc.y * tanHalf, -1.0));
  vec3 origin = vec3(0.0, 0.0, 30.0);
  float cx = cos(uTilt.x);
  float sx = sin(uTilt.x);
  float cy = cos(uTilt.y);
  float sy = sin(uTilt.y);
  mat3 rotation = mat3(1.0, 0.0, 0.0, 0.0, cx, sx, 0.0, -sx, cx) * mat3(cy, 0.0, -sy, 0.0, 1.0, 0.0, sy, 0.0, cy);
  vec3 normal = rotation * vec3(0.0, 0.0, 1.0);
  float facing = dot(dir, normal);
  if (abs(facing) < 0.0001) return vec4(0.0);
  vec3 hit = origin + dir * (-dot(origin, normal) / facing);
  vec3 local = transpose(rotation) * hit;
  float planeHeight = 24.8528 * uPlaneHeight;
  float planeWidth = planeHeight * uTextAspect;
  float wave = 5.0 * sin(uTime * uWaveSpeed);
  local.x -= sin(wave + local.y) * 0.5 * uWaves;
  local.y -= cos(wave) * 0.15 * uWaves;
  local.xy /= 1.0 + sin(wave + local.x) * uWaves / 30.0;
  vec2 uv = vec2(local.x / planeWidth + 0.5, 0.5 - local.y / planeHeight);
  float t = sin(uTime);
  float red = texture(uText, uv + cos(t + uv.x) * 0.01 * uChroma).r;
  float green = texture(uText, uv + clamp(tan(uv.x - t * 0.5), -3.0, 3.0) * 0.01 * uChroma).g;
  float blue = texture(uText, uv - cos(t * 3.0 + uv.y) * 0.01 * uChroma).b;
  vec4 base = texture(uText, uv);
  float inside = step(0.0, uv.x) * step(uv.x, 1.0) * step(0.0, uv.y) * step(uv.y, 1.0);
  return vec4(red, green, blue, base.a) * inside;
}

void main() {
  vec2 pixel = vec2(gl_FragCoord.x, uSize.y - gl_FragCoord.y);
  vec2 cell = floor(pixel / uCell);
  vec2 local = fract(pixel / uCell);
  vec2 center = (cell + 0.5) * uCell;
  float tick = floor(uTime * 18.0);

  float ring = 0.0;
  vec2 push = vec2(0.0);
  for (int i = 0; i < RIPPLES; i++) {
    vec4 ripple = uRipples[i];
    if (ripple.w <= 0.0) continue;
    float radius = ripple.z * max(uSize.x, uSize.y) * 0.75;
    float gap = abs(distance(center, ripple.xy) - radius);
    float band = max(uCell.y * 3.0, 24.0);
    float strength = (1.0 - smoothstep(0.0, 1.2, ripple.z)) * (1.0 - smoothstep(0.0, band, gap));
    ring = max(ring, strength);
    push += normalize(center - ripple.xy + 0.001) * strength * uCell.y * 1.5;
  }

  vec4 base = scene(center - push);
  float content = step(0.02, base.a);
  float gray = clamp(dot(base.rgb, vec3(0.3, 0.6, 0.1)), 0.0, 1.0);
  float index = content > 0.0 ? max(1.0, floor(gray * (uGlyphCount - 1.0) + 0.5)) : 0.0;
  float randomGlyph = 1.0 + floor(hash(cell * 1.7 + tick * 0.37) * (uGlyphCount - 1.0));

  float reach = uSize.y * 0.18 * (0.5 + uScramble);
  float scramble = uHover * uScramble * (1.0 - smoothstep(reach * 0.35, reach, distance(center, uPointer)));
  if (content > 0.0 && hash(cell + tick * 7.13) < scramble * 0.8) index = randomGlyph;
  if (hash(cell + tick * 3.1) < ring) index = randomGlyph;
  float decoding = step(hash(cell * 0.37 + 2.1), uIntro);
  if (content > 0.0 && decoding > 0.0) index = randomGlyph;

  float mask = texture(uGlyphs, vec2((index + local.x) / uGlyphCount, local.y)).a;
  float glyphAlpha = mask * max(content * (1.0 - decoding * 0.35), ring * 0.75);

  float spread = length((pixel - uSize * 0.5) / (uSize * 0.5)) * 0.7071;
  vec3 tint = mix(mix(uColors[0], uColors[1], smoothstep(0.0, 0.5, spread)), uColors[2], smoothstep(0.5, 1.0, spread));
  float blockAlpha = base.a * uBlocks * (1.0 - uIntro);
  vec3 under = base.rgb * blockAlpha;
  vec3 color = mix(under, abs(tint - under), glyphAlpha);
  float alpha = max(blockAlpha, glyphAlpha) * uReady;
  color = clamp(hueRotate(color, uHue), 0.0, 1.0) * uReady;
  if (uLight > 0.5) color = vec3(alpha) - color;
  fragColor = vec4(color, alpha);
}`,E=(l,h,s)=>Math.min(s,Math.max(h,l)),ue=(l,h,s)=>{const n=l.createShader(h);return n?(l.shaderSource(n,s),l.compileShader(n),l.getShaderParameter(n,l.COMPILE_STATUS)?n:(l.deleteShader(n),null)):null},Xe=l=>{const h=document.createElement("canvas").getContext("2d");if(!h)return[1,1,1];h.fillStyle="#ffffff",h.fillStyle=l;const s=String(h.fillStyle);if(s.startsWith("#")){const c=parseInt(s.slice(1,7),16);return[(c>>16&255)/255,(c>>8&255)/255,(c&255)/255]}const n=s.match(/[\d.]+/g)?.map(Number)??[255,255,255];return[n[0]/255,n[1]/255,n[2]/255]},Ge=(l,h,s,n)=>{const c=document.createElement("canvas"),p=c.getContext("2d");if(!p)return null;const R=`${s} ${C}px ${h}`;p.font=R;const P=Math.max(C*.6,p.measureText(l||" ").width);return c.width=Math.ceil(P+C*.3),c.height=Math.ceil(C*1.3),p.font=R,p.fillStyle=n,p.textAlign="center",p.textBaseline="middle",p.fillText(l,c.width/2,c.height/2),c},He=(l,h)=>{const s=document.createElement("canvas"),n=s.getContext("2d");return n?(s.width=l.length*F,s.height=A,n.font=`500 ${A*.74}px ${h}`,n.fillStyle="#ffffff",n.textAlign="center",n.textBaseline="middle",Array.from(l).forEach((c,p)=>{n.fillText(c,p*F+F/2,A/2+A*.04)}),s):null};function ke({text:l="Hey!",asciiFontSize:h=8,charset:s=ce,fontFamily:n=we,fontWeight:c=600,textColor:p="#fdf9f3",colors:R=["#ff6188","#fc9867","#ffd866"],textScale:P=1,blocks:fe=.9,waves:he=1,waveSpeed:pe=1,chroma:me=1,tilt:de=1,hueShift:ve=1,scramble:xe=.6,clickRipple:ge=!0,intro:Te=!0,idle:ye=!0,interactive:Ee=!0,theme:Re="dark",className:Se="",style:be}){const $=T.useRef(null),O=T.useRef(null),H=T.useRef(null),[Ae,Ce]=T.useState(!1),z=Array.from(s).length>1?s:ce,y=(R?.length?R:["#ffffff"]).slice(0,3),j={cellSize:Math.max(3,h),textScale:E(P,.1,3),blocks:E(fe,0,1),waves:Math.max(0,he),waveSpeed:Math.max(0,pe),chroma:Math.max(0,me),tilt:Math.max(0,de),hueShift:E(ve,0,2),scramble:E(xe,0,1),clickRipple:ge,intro:Te,idle:ye,interactive:Ee,light:Re==="light",colors:[y[0],y[1]??y[0],y[2]??y[1]??y[0]]},M=T.useRef(j);return M.current=j,T.useEffect(()=>{const f=$.current,m=O.current;if(!f||!m)return;const v=window.matchMedia?.("(prefers-reduced-motion: reduce)").matches??!1,e=m.getContext("webgl2",{alpha:!0,premultipliedAlpha:!0,antialias:!1});let d=null,U=null,_=null,w=null;const a={};if(e){const r=ue(e,e.VERTEX_SHADER,Le),o=ue(e,e.FRAGMENT_SHADER,Ie);if(r&&o&&(d=e.createProgram(),e.attachShader(d,r),e.attachShader(d,o),e.bindAttribLocation(d,0,"position"),e.linkProgram(d),e.deleteShader(r),e.deleteShader(o),e.getProgramParameter(d,e.LINK_STATUS)||(e.deleteProgram(d),d=null)),d){U=e.createBuffer(),e.bindBuffer(e.ARRAY_BUFFER,U),e.bufferData(e.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),e.STATIC_DRAW),e.enableVertexAttribArray(0),e.vertexAttribPointer(0,2,e.FLOAT,!1,0,0),_=e.createTexture(),w=e.createTexture();for(const i of["uText","uGlyphs","uSize","uCell","uGlyphCount","uTextAspect","uPlaneHeight","uTilt","uTime","uWaves","uWaveSpeed","uChroma","uBlocks","uColors","uHue","uPointer","uHover","uScramble","uRipples","uIntro","uLight","uReady"])a[i]=e.getUniformLocation(d,i)}}if(!e||!d){Ce(!0);return}const K=(r,o,i)=>{e.bindTexture(e.TEXTURE_2D,r),e.pixelStorei(e.UNPACK_FLIP_Y_WEBGL,!1),e.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),e.texImage2D(e.TEXTURE_2D,0,e.RGBA,e.RGBA,e.UNSIGNED_BYTE,o),e.generateMipmap(e.TEXTURE_2D),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MIN_FILTER,i?e.LINEAR_MIPMAP_LINEAR:e.NEAREST),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MAG_FILTER,i?e.LINEAR:e.NEAREST),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_S,e.CLAMP_TO_EDGE),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_T,e.CLAMP_TO_EDGE)},t={ready:!1,textAspect:1,glyphCount:1,time:0,tiltX:0,tiltY:0,hue:0,hover:0,intro:0,pointerX:0,pointerY:0,targetX:0,targetY:0,inside:!1,visible:!0,ripples:[],introPlayed:!1},k=new Float32Array(N*4),q=new Float32Array(9);let V="",S=0,D=performance.now(),B=!0;const Pe=(r,o,i,u,x,I)=>{const g=Ge(r,o,i,u),X=He(x,o);!g||!X||(K(_,g,!1),K(w,X,!0),t.textAspect=g.width/g.height,t.glyphCount=Array.from(x).length,t.ready=!0,M.current.intro&&!t.introPlayed&&!v&&(t.introPlayed=!0,t.intro=1))};let Y=!1,J=1;const Me=()=>{const r=Math.min(window.devicePixelRatio||1,2),o=Math.max(1,f.clientWidth),i=Math.max(1,Math.round(o*r)),u=Math.max(1,Math.round(f.clientHeight*r));J=i/o,(m.width!==i||m.height!==u)&&(m.width=i,m.height=u)},Q=()=>{Y=!0,L()},Z=r=>{if(S=0,Y&&(Y=!1,Me()),!B)return;const o=M.current,i=Math.min(.05,Math.max(.001,(r-D)/1e3));D=r,t.time+=v?0:i;const u=J;let x=0,I=0;o.interactive&&t.inside?(x=t.targetY*.5*o.tilt,I=t.targetX*.5*o.tilt):o.idle&&!v&&(x=Math.sin(t.time*.55)*.12*o.tilt,I=Math.sin(t.time*.4+1.3)*.2*o.tilt);const g=1-Math.exp(-i/.3);t.tiltX+=(x-t.tiltX)*g,t.tiltY+=(I-t.tiltY)*g;const X=Math.atan2(t.targetY,t.targetX);let G=(o.interactive&&t.inside?X*o.hueShift:t.hue)-t.hue;G=Math.atan2(Math.sin(G),Math.cos(G)),t.hue+=G*(1-Math.exp(-i/.25)),t.hover+=((o.interactive&&t.inside?1:0)-t.hover)*(1-Math.exp(-i/.2)),t.intro>0&&(t.intro=Math.max(0,t.intro-i/1.4)),k.fill(0),t.ripples=t.ripples.filter(b=>(b.age+=i)<1.3),t.ripples.slice(-N).forEach((b,_e)=>{k.set([b.x*u,b.y*u,b.age,1],_e*4)});const ie=m.width,le=m.height;e.viewport(0,0,ie,le),e.clearColor(0,0,0,0),e.clear(e.COLOR_BUFFER_BIT),e.useProgram(d),e.activeTexture(e.TEXTURE0),e.bindTexture(e.TEXTURE_2D,_),e.uniform1i(a.uText,0),e.activeTexture(e.TEXTURE1),e.bindTexture(e.TEXTURE_2D,w),e.uniform1i(a.uGlyphs,1),e.uniform2f(a.uSize,ie,le),e.uniform2f(a.uCell,o.cellSize*.62*u,o.cellSize*u),e.uniform1f(a.uGlyphCount,t.glyphCount),e.uniform1f(a.uTextAspect,t.textAspect),e.uniform1f(a.uPlaneHeight,.5*o.textScale),e.uniform2f(a.uTilt,t.tiltX,t.tiltY),e.uniform1f(a.uTime,t.time),e.uniform1f(a.uWaves,o.waves),e.uniform1f(a.uWaveSpeed,o.waveSpeed),e.uniform1f(a.uChroma,o.chroma),e.uniform1f(a.uBlocks,o.blocks);const se=o.colors.join();se!==V&&(V=se,q.set(o.colors.flatMap(Xe))),e.uniform3fv(a.uColors,q),e.uniform1f(a.uHue,t.hue),e.uniform2f(a.uPointer,t.pointerX*u,t.pointerY*u),e.uniform1f(a.uHover,t.hover),e.uniform1f(a.uScramble,o.scramble),e.uniform4fv(a.uRipples,k),e.uniform1f(a.uIntro,t.intro),e.uniform1f(a.uLight,o.light?1:0),e.uniform1f(a.uReady,t.ready?1:0),e.drawArrays(e.TRIANGLES,0,3),t.visible&&(S=requestAnimationFrame(Z))},L=()=>{S||!B||!t.visible||(D=performance.now(),S=requestAnimationFrame(Z))};H.current=(r,o,i,u,x)=>{Pe(r,o,i,u,x),L()};const ee=r=>{const o=f.getBoundingClientRect(),i=r.clientX-o.left,u=r.clientY-o.top;t.pointerX=i,t.pointerY=u,t.targetX=E(i/Math.max(1,o.width)*2-1,-1,1),t.targetY=E(u/Math.max(1,o.height)*2-1,-1,1)},te=r=>{ee(r),t.inside=!0},oe=()=>{t.inside=!1},ne=r=>{const o=M.current;!o.interactive||!o.clickRipple||(ee(r),t.ripples.push({x:t.pointerX,y:t.pointerY,age:0}))},re=new ResizeObserver(Q);re.observe(f);const ae=new IntersectionObserver(r=>{t.visible=r.some(o=>o.isIntersecting),t.visible&&L()});return ae.observe(f),f.addEventListener("pointermove",te),f.addEventListener("pointerdown",ne),f.addEventListener("pointerleave",oe),Q(),L(),()=>{B=!1,cancelAnimationFrame(S),H.current=null,re.disconnect(),ae.disconnect(),f.removeEventListener("pointermove",te),f.removeEventListener("pointerdown",ne),f.removeEventListener("pointerleave",oe),e.deleteTexture(_),e.deleteTexture(w),e.deleteBuffer(U),e.deleteProgram(d),m.isConnected||e.getExtension("WEBGL_lose_context")?.loseContext()}},[]),T.useEffect(()=>{let f=!1;const m=()=>{f||H.current?.(l,n,c,p,z)};m();const v=document.fonts;return v?.load&&Promise.all([v.load(`${c} ${C}px ${n}`,l||"A"),v.load(`500 ${A}px ${n}`,z)]).catch(()=>null).then(m),v?.addEventListener?.("loadingdone",m),()=>{f=!0,v?.removeEventListener?.("loadingdone",m)}},[l,n,c,p,z]),W.jsxs("div",{ref:$,className:Se,style:{position:"absolute",inset:0,touchAction:"pan-y",...be},"aria-label":l,role:"img",children:[W.jsx("canvas",{ref:O,style:{position:"absolute",inset:0,width:"100%",height:"100%",display:"block"}}),Ae&&W.jsx("div",{style:{position:"absolute",inset:0,display:"flex",alignItems:"center",justifyContent:"center",fontFamily:n,fontWeight:c,fontSize:`${8*P}vw`,color:p},children:l})]})}export{ke as default};
