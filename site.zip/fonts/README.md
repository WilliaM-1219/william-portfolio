# Reference typefaces

These WOFF2 files are the exact Latin subsets publicly linked by the reference homepage.
They are served locally; no runtime font requests to external domains are required.

| File | Family | Style | CSS weight |
|---|---|---|---|
| plus-jakarta-sans-latin-variable.woff2 | Plus Jakarta Sans | normal | 200 800 |
| cormorant-garamond-latin-500-italic.woff2 | Cormorant Garamond | italic | 500 |

Styles and weight ranges were verified against `<style data-vinext-fonts>` in the public reference HTML. These subsets cover Latin; Chinese text uses a Chinese system-font fallback.

Both families are published under the SIL Open Font License 1.1. The corresponding full OFL texts were fetched from the official Google Fonts repository and are retained alongside the fonts. Source URLs and SHA-256 hashes are in font-sources.json. The font binaries are unmodified.
